﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReadOnlyApi.Infrastructure.Contracts
{
    public interface ICosmosDbContainerFactory
    {
        /// <summary>
        ///     Returns a CosmosDbContainer wrapper
        /// </summary>
        /// <param name="containerName"></param>
        /// <returns></returns>
        ICosmosDbContainer GetContainer(string containerName);
    }
}
