﻿using Microsoft.Azure.Cosmos;
using System;
using System.Collections.Generic;
using System.Text;

namespace ReadOnlyApi.Infrastructure.Contracts
{
    public interface ICosmosDbContainer
    {
        Container _container { get; }
    }
}
