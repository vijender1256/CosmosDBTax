﻿using Microsoft.Azure.Cosmos;
using ReadOnlyApi.Infrastructure.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ReadOnlyApi.Infrastructure
{
    public class CosmosDbContainer : ICosmosDbContainer
    {
        public Container _container { get; }

        public CosmosDbContainer(CosmosClient cosmosClient,
                                 string databaseName,
                                 string containerName)
        {
            this._container = cosmosClient.GetContainer(databaseName, containerName);
        }
    }
}
