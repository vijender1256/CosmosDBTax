﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReadOnlyApi.Infrastructure.Models
{
    public class ErrorDetails
    {
        public string Code { get; set; } = "";
        public string Message { get; set; } = "";
        public string Severity { get; set; } = "";
    }
}
