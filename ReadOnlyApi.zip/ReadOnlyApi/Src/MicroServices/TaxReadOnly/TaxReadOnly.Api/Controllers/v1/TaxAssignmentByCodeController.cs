﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxReadOnly.Api.Application.Queries;
using MediatR;

namespace TaxReadOnly.Api.Controllers.v1
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class TaxAssignmentByCodeController : ApiBaseController
    {
        public TaxAssignmentByCodeController(IMediator mediator) : base(mediator)
        { }

        /// <summary>
        ///  Returns Application Details.
        /// </summary>
        /// <param name="query"> GetApplicationDetails Query.</param>
        /// <returns> Returns Application Details..</returns>
        [HttpGet("getTaxByItemCode")]
        [ProducesResponseType(typeof(GetTaxAssignmentByItemCodeVm), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<GetTaxAssignmentByItemCodeVm>> GetTaxByItemCode(string code, int taxTypeCode)
        {
            var query = new GetTaxAssignmentByItemCodeQuery() { Code = code, TaxTypeCode = taxTypeCode };
            return Single(await QueryAsync(query));
        }

        /// <summary>
        ///  Returns Application Details.
        /// </summary>
        /// <param name="query"> GetApplicationDetails Query.</param>
        /// <returns> Returns Application Details..</returns>
        [HttpGet("getTaxByScanCode")]
        [ProducesResponseType(typeof(GetTaxAssignmentByScanCodeVm), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<GetTaxAssignmentByScanCodeVm>> GetTaxByScanCode(string code, int taxTypeCode)
        {
            var query = new GetTaxAssignmentByScanCodeQuery() { Code = code, TaxTypeCode = taxTypeCode };
            return Single(await QueryAsync(query));
        }
    }
}
