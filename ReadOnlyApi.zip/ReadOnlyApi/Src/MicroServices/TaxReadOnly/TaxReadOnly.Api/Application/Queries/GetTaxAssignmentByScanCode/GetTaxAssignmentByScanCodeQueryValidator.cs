﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaxReadOnly.Api.Application.Queries
{
    public class GetTaxAssignmentByScanCodeQueryValidator : AbstractValidator<GetTaxAssignmentByScanCodeQuery>
    {
        public GetTaxAssignmentByScanCodeQueryValidator()
        {
            RuleFor(query => Convert.ToInt64(query.Code))
                .InclusiveBetween(1, 2147483647)
                .WithMessage(" Scan Code range to be between 1 And 2147483647");
        }
    }
}