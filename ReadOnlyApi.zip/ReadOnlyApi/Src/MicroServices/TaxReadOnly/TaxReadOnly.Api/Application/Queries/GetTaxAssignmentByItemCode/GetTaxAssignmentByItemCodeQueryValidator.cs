﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaxReadOnly.Api.Application.Queries
{
    public class GetTaxAssignmentByItemCodeQueryValidator : AbstractValidator<GetTaxAssignmentByItemCodeQuery>
    {
        public GetTaxAssignmentByItemCodeQueryValidator()
        {
            RuleFor(query => Convert.ToInt64(query.Code))
                .InclusiveBetween(1, 2147483647)
                .WithMessage(" Item code range to be between 1 And 2147483647");
        }
    }
}
