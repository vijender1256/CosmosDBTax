﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaxReadOnly.Api.Application.Models;
using TaxReadOnly.Api.Mappings;
using TaxReadOnly.Domain.Entities;

namespace TaxReadOnly.Api.Application.Queries
{
    public class GetTaxAssignmentByItemCodeVm : BaseEntityVm, IMapFrom<TaxAssignmentByArea>
    {
        public string Id { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public List<TaxPlanVm> TaxPlan { get; set; }
    }
}
