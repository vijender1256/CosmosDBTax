﻿using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using TaxReadOnly.Domain.Entities;
using TaxReadOnly.Infrastructure.Contracts;

namespace TaxReadOnly.Api.Application.Queries
{
    /// <summary>
    /// This class represents api's query input model and returns the response object
    /// </summary>
    public class GetTaxAssignmentByItemCodeQuery : IRequest<GetTaxAssignmentByItemCodeVm>
    {
        public string Code { get; set; }
        public int TaxTypeCode { get; set; }
    }

    /// <summary>
    /// This class handles the query to fetch data and build response
    /// </summary>
    public class GetTaxAssignmentByItemCodeQueryHandler : IRequestHandler<GetTaxAssignmentByItemCodeQuery, GetTaxAssignmentByItemCodeVm>
    {
        private readonly ITaxByAreaRepository _repoTaxArea;
        private readonly IMapper mapper;

        public GetTaxAssignmentByItemCodeQueryHandler(IMapper mapper,
            ITaxByAreaRepository repoTaxArea)
        {
            this.mapper = mapper;
            this._repoTaxArea = repoTaxArea;

        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<GetTaxAssignmentByItemCodeVm> Handle(GetTaxAssignmentByItemCodeQuery request, CancellationToken cancellationToken)
        {
            var taxAssignPlnByAreaResponse = new GetTaxAssignmentByItemCodeVm();
            try
            {
                var taxAssgnByArea = await _repoTaxArea.GetTaxAsyncByArea(request.Code, request.TaxTypeCode, "ItemCode");

                if (taxAssgnByArea != null)
                {
                    taxAssignPlnByAreaResponse = this.mapper.Map<GetTaxAssignmentByItemCodeVm>(taxAssgnByArea);

                    taxAssignPlnByAreaResponse.ResponseCode = "TAX001";
                    taxAssignPlnByAreaResponse.ResponseMessage = "Tax look for itemcode: 4 is successful";
                }
                else
                {
                    taxAssignPlnByAreaResponse.ResponseCode = "TAX002";
                    taxAssignPlnByAreaResponse.ResponseMessage = "No tax found for itemcode: 4";
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return taxAssignPlnByAreaResponse;
        }
    }
}
