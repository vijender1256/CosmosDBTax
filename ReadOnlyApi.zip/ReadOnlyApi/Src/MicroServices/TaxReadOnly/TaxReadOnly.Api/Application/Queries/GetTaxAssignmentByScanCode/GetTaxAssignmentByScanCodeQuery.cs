﻿using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using TaxReadOnly.Infrastructure.Contracts;

namespace TaxReadOnly.Api.Application.Queries
{
    /// <summary>
    /// This class represents api's query input model and returns the response object
    /// </summary>
    public class GetTaxAssignmentByScanCodeQuery : IRequest<GetTaxAssignmentByScanCodeVm>
    {
        public string Code { get; set; }
        public int TaxTypeCode { get; set; }
    }

    /// <summary>
    /// This class handles the query to fetch data and build response
    /// </summary>
    public class GetTaxAssignmentByScanCodeQueryHandler : IRequestHandler<GetTaxAssignmentByScanCodeQuery, GetTaxAssignmentByScanCodeVm>
    {
        private readonly ITaxByAreaRepository _repoTaxArea;
        private readonly IMapper mapper;

        public GetTaxAssignmentByScanCodeQueryHandler(IMapper mapper,
            ITaxByAreaRepository repoTaxArea)
        {
            this.mapper = mapper;
            this._repoTaxArea = repoTaxArea;

        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<GetTaxAssignmentByScanCodeVm> Handle(GetTaxAssignmentByScanCodeQuery request, CancellationToken cancellationToken)
        {
            var taxAssignPlnByAreaResponse = new GetTaxAssignmentByScanCodeVm();
            try
            {
                var taxAssgnByArea = await _repoTaxArea.GetTaxAsyncByArea(request.Code, request.TaxTypeCode, "ScanCode");

                if (taxAssgnByArea != null)
                {
                    taxAssignPlnByAreaResponse = this.mapper.Map<GetTaxAssignmentByScanCodeVm>(taxAssgnByArea);
                }
            }
            catch
            {
                throw;
            }
            return taxAssignPlnByAreaResponse;
        }
    }
}