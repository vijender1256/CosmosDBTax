﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaxReadOnly.Api.Mappings;
using TaxReadOnly.Domain.Entities;

namespace TaxReadOnly.Api.Application.Models
{
    public class TaxPlanVm : IMapFrom<TaxPlanInfo>
    {
        public int TaxTypeCode { get; set; }
        public string TaxTypeDescription { get; set; }
        public string POSTaxEnabled { get; set; }
        public string POSTaxField { get; set; }

        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }

        public string State { get; set; }
        public string CityOrCounty { get; set; }

        public decimal? PercentageRate { get; set; }
        public decimal? FlatRate { get; set; }

        public void Mapping(Profile profile)
        {
            profile.CreateMap<TaxPlanInfo, TaxPlanVm>()
                .ForMember(dest => dest.State, opt => opt.MapFrom(src => src.StateShorName))
                .ForMember(dest => dest.CityOrCounty, opt => opt.MapFrom(src => !string.IsNullOrWhiteSpace(src.City) ? src.City : src.County));
        }
    }
}
