﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace TaxReadOnly.Api.Application.PipelineBehaviours
{
    public class WebApiCustomMiddleware
    {
        private readonly RequestDelegate _next;

        public WebApiCustomMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            //process context.Request
            //to do like validating any thing on request, open id conenct..

            await _next(context);

            //process context.Response
            if (context.Response.StatusCode == (int)HttpStatusCode.NotFound)
            {
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync(JsonConvert.SerializeObject(new
                {
                    code = 404,
                    message = "resource not found"
                }));
            }
        }
    }
}
