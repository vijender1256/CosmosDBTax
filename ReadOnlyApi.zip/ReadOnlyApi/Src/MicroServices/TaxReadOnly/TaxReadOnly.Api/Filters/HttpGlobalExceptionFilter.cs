﻿using AutoMapper;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ReadOnlyApi.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using TaxReadOnly.Api.ActionResults;
using TaxReadOnly.Domain.Exceptions;

namespace TaxReadOnly.Api.Filters
{
    public class HttpGlobalExceptionFilter : IExceptionFilter
    {
        private readonly IWebHostEnvironment env;
        private readonly ILogger<HttpGlobalExceptionFilter> logger;
        private readonly IMapper mapper;

        public HttpGlobalExceptionFilter(IWebHostEnvironment env, IMapper mapper, ILogger<HttpGlobalExceptionFilter> logger)
        {
            this.env = env;
            this.logger = logger;
            this.mapper = mapper;
        }

        public void OnException(ExceptionContext context)
        {
            logger.LogError(new EventId(context.Exception.HResult),
                context.Exception,
                context.Exception.Message);

            var json = new JsonErrorResponse();

            if (context.Exception.GetType() == typeof(TaxReadOnlyApiCustomException))
            {
                var xCeption = (TaxReadOnlyApiCustomException)context.Exception;

                if (xCeption.Errors != null && xCeption.Errors.Count() > 0)
                {
                    json.Errors = xCeption.Errors.ToArray();
                }
                else
                {
                    json.Errors = new List<ErrorDetails>()
                                          { new ErrorDetails() { Message = context.Exception.Message } }.ToArray();
                }

                context.Result = new BadRequestObjectResult(json);
                context.HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
            }
            else if (context.Exception.GetType() == typeof(ValidationException))
            {
                var xCeption = (ValidationException)context.Exception;

                if (xCeption.Errors != null && xCeption.Errors.Count() > 0)
                {
                    var errors = mapper.Map<IEnumerable<ValidationFailure>, IEnumerable<ErrorDetails>>(xCeption.Errors);

                    json.Errors = errors.ToArray(); // xCeption.Errors.Select(e => e.ErrorMessage).ToArray()

                    context.Result = new BadRequestObjectResult(json);
                    context.HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                json.Errors = new[] { "An unexpected error occurred. Try it again Vijju." };

                if (env.IsDevelopment())
                {
                    json.DeveloperMessage = context.Exception;
                }

                context.Result = new InternalServerErrorObjectResult(json);
                context.HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            }
        }

        private class JsonErrorResponse
        {
            public object[] Errors { get; set; }
            public object DeveloperMessage { get; set; }
        }

        public class MappingProfile : Profile
        {
            public MappingProfile()
            {
                CreateMap<ValidationFailure, ErrorDetails>()
                    .ForMember(dest => dest.Code, opt => opt.MapFrom(src => ""))
                    .ForMember(dest => dest.Message, opt => opt.MapFrom(src => src.ErrorMessage))
                    .ForMember(dest => dest.Severity, opt => opt.MapFrom(src => src.Severity.ToString()));
            }
        }
    }
}
