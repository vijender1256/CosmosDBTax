﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaxReadOnly.Api.Contracts;
using TaxReadOnly.Infrastructure.Contracts;
using TaxReadOnly.Infrastructure.Repositories;

namespace TaxReadOnly.Api.Installers
{
    public class RegisterContractMappings : IServiceRegistration
    {
        public void RegisterAppServices(IServiceCollection services, IConfiguration config)
        {
            services.AddTransient<ITaxByAreaRepository, TaxByAreaRepository>();
        }
    }
}
