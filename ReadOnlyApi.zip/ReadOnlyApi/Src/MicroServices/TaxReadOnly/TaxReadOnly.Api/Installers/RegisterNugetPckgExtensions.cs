﻿using AutoMapper;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaxReadOnly.Api.Application.PipelineBehaviours;
using TaxReadOnly.Api.Contracts;

namespace TaxReadOnly.Api.Installers
{
    public class RegisterNugetPckgExtensions : IServiceRegistration
    {
        public void RegisterAppServices(IServiceCollection services, IConfiguration config)
        {
            // register MediatR & pipeline behaviours
            services.AddMediatR(typeof(Startup))
                    .AddTransient(serviceType: typeof(IPipelineBehavior<,>), implementationType: typeof(ValidatorPipelineBehavior<,>))
                    .AddTransient(serviceType: typeof(IPipelineBehavior<,>), implementationType: typeof(PerformanceBehavior<,>));

            // register fluentvalidator  
            services.AddValidatorsFromAssembly(typeof(Startup).Assembly);

            // registers automapper
            services.AddAutoMapper(typeof(Startup));
        }
    }
}
