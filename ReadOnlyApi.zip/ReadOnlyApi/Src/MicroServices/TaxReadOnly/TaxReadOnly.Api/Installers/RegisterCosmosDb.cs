﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ReadOnlyApi.Infrastructure;
using ReadOnlyApi.Infrastructure.Configurations;
using ReadOnlyApi.Infrastructure.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using TaxReadOnly.Api.Contracts;

namespace TaxReadOnly.Api.Installers
{
    public class RegisterCosmosDb : IServiceRegistration
    {
        public void RegisterAppServices(IServiceCollection services, IConfiguration config)
        {
            string[] blist = { "www.publix.com" };

            CosmosClientOptions clientOptions = new CosmosClientOptions()
            {
                WebProxy = new WebProxy("http://webproxy1.publix.inet:9090", true, blist, CredentialCache.DefaultNetworkCredentials),
                ConnectionMode = ConnectionMode.Gateway
            };

            // Bind database-related bindings
            CosmosDbSettings cosmosDbConfig = config.GetSection("ConnectionStrings:cosmosDb").Get<CosmosDbSettings>();

            CosmosClient client = new CosmosClient(cosmosDbConfig.EndpointUrl, cosmosDbConfig.PrimaryKey, clientOptions);
            CosmosDbContainerFactory cosmosDbClientFactory = new CosmosDbContainerFactory(client, cosmosDbConfig.DatabaseName, cosmosDbConfig.Containers);

            services.AddSingleton<ICosmosDbContainerFactory>(cosmosDbClientFactory);
        }
    }
}
