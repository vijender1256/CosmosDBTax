﻿using ReadOnlyApi.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace TaxReadOnly.Domain.Exceptions
{
    public class TaxReadOnlyApiCustomException : Exception
    {
        public IEnumerable<ErrorDetails> Errors { get; private set; }

        public TaxReadOnlyApiCustomException()
        { }

        public TaxReadOnlyApiCustomException(string message)
            : base(message)
        { }

        public TaxReadOnlyApiCustomException(IEnumerable<ErrorDetails> errors)
        {
            Errors = errors;
        }

        public TaxReadOnlyApiCustomException(string message, Exception innerException)
            : base(message, innerException)
        { }
    }
}