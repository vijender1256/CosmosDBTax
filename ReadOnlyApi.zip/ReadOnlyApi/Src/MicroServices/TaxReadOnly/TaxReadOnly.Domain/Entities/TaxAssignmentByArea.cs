﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace TaxReadOnly.Domain.Entities
{
    public class TaxAssignmentByArea : BaseEntity
    {
        public string Code { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public List<TaxPlanInfo> TaxPlan { get; set; }
    }
}
