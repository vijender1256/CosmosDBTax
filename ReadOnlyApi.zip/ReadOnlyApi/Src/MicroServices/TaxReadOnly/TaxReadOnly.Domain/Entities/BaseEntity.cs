﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace TaxReadOnly.Domain.Entities
{
    public abstract class BaseEntity
    {
        [JsonProperty(PropertyName = "id")]
        public virtual string Id { get; set; }
    }
}
