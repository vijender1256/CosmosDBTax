﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace TaxReadOnly.Domain.Entities
{
    public class TaxPlanInfo
    {
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public Int32? ItemCode { get; set; }
        public DateTime? ScanCodeEffectiveDate { get; set; }
        public Int32? ScanCode { get; set; }
        
        public int TaxTypeCode { get; set; }
        public string TaxArea { get; set; }
        public string TaxTypeDescription { get; set; }
        public string POSTaxEnabled { get; set; }
        public string POSTaxField { get; set; }
        public int SortOrder { get; set; }
        public string InCityLimitTag { get; set; }


        public int LocationId { get; set; }
        public string LocationType { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string County { get; set; }
        public Int32? CountyCode { get; set; }
        public string State { get; set; }
        public string StateShorName { get; set; }
        public Int32? FK_LocationId { get; set; }
        public Int32? SortSequence { get; set; }


        public DateTime? TaxEffectiveDate { get; set; }
        public decimal? PercentageRate { get; set; }
        public decimal? FlatRate { get; set; }
        public string TaxAuthority { get; set; }
        public string DueDate { get; set; }
    }
}
