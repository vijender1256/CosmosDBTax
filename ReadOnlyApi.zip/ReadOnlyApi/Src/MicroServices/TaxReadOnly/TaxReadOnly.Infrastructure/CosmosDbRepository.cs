﻿using Microsoft.Azure.Cosmos;
using ReadOnlyApi.Infrastructure.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxReadOnly.Domain.Entities;
using TaxReadOnly.Infrastructure.Contracts;

namespace TaxReadOnly.Infrastructure
{
    public abstract class CosmosDbRepository<T> : IRepository<T> where T : BaseEntity
    {
        /// <summary>
        ///     Name of the CosmosDB container
        /// </summary>
        public abstract string ContainerName { get; }

        ///// <summary>
        /////     Generate id
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public abstract string GenerateId(T entity);

        ///// <summary>
        /////     Resolve the partition key
        ///// </summary>
        ///// <param name="entityId"></param>
        ///// <returns></returns>
        //public abstract PartitionKey ResolvePartitionKey(string entityId);


        private readonly ICosmosDbContainerFactory _cosmosDbContainerFactory;

        private readonly Container _container;

        public CosmosDbRepository(ICosmosDbContainerFactory cosmosDbContainerFactory)
        {
            this._cosmosDbContainerFactory = cosmosDbContainerFactory ?? throw new ArgumentNullException(nameof(ICosmosDbContainerFactory));
            this._container = this._cosmosDbContainerFactory.GetContainer(ContainerName)._container;
        }

        // Search data using SQL query string
        // This shows how to use SQL string to read data from Cosmos DB for demonstration purpose.
        // For production, try to use safer alternatives like Parameterized Query and LINQ if possible.
        // Using string can expose SQL Injection vulnerability, e.g. select * from c where c.id=1 OR 1=1. 
        // String can also be hard to work with due to special characters and spaces when advanced querying like search and pagination is required.
        public async Task<IEnumerable<T>> GetItemsAsync(QueryDefinition queryString)
        {
            FeedIterator<T> resultSetIterator = _container.GetItemQueryIterator<T>(queryString);
            List<T> results = new List<T>();
            while (resultSetIterator.HasMoreResults)
            {
                FeedResponse<T> response = await resultSetIterator.ReadNextAsync();

                results.AddRange(response.ToList());
            }

            return results;
        }
    }
}
