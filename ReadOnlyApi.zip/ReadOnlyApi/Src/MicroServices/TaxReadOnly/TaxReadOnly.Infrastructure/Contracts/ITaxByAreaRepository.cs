﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TaxReadOnly.Domain.Entities;

namespace TaxReadOnly.Infrastructure.Contracts
{
    public interface ITaxByAreaRepository
    {
        Task<TaxAssignmentByArea> GetTaxAsyncByArea(string code, int taxTypeCode, string type);
    }
}
