﻿using Microsoft.Azure.Cosmos;
using ReadOnlyApi.Infrastructure.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxReadOnly.Domain.Entities;
using TaxReadOnly.Infrastructure.Contracts;

namespace TaxReadOnly.Infrastructure.Repositories
{
    public class TaxByAreaRepository : CosmosDbRepository<TaxAssignmentByArea>, ITaxByAreaRepository
    {

        /// <summary>
        ///     CosmosDB container name
        /// </summary>
        public override string ContainerName { get; } = "TaxAssignmentByArea";

        ///// <summary>
        /////     Generate Id.
        /////     e.g. "shoppinglist:783dfe25-7ece-4f0b-885e-c0ea72135942"
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public override string GenerateId(ToDoItem entity) => $"{entity.Category}:{Guid.NewGuid()}";

        ///// <summary>
        /////     Returns the value of the partition key
        ///// </summary>
        ///// <param name="entityId"></param>
        ///// <returns></returns>
        //public override PartitionKey ResolvePartitionKey(string entityId) => new PartitionKey(entityId.Split(':')[0]);

        public TaxByAreaRepository(ICosmosDbContainerFactory factory) : base(factory)
        { }

        // Use Cosmos DB Parameterized Query to avoid SQL Injection.
        public async Task<TaxAssignmentByArea> GetTaxAsyncByArea(string code, int taxTypeCode, string type)
        {
            IEnumerable<TaxAssignmentByArea> results;

            string query = @$"SELECT * FROM c WHERE c.code = @code and c.type = @type";

            QueryDefinition queryDefinition = new QueryDefinition(query)
                                                    .WithParameter("@code", code)
                                                    .WithParameter("@type", type);

            results = await this.GetItemsAsync(queryDefinition);

            if (taxTypeCode > 0)
            {
                results?.ToList().ForEach(n => n.TaxPlan = n.TaxPlan?.Where(x => x.TaxTypeCode == taxTypeCode).ToList());
            }

            return results.FirstOrDefault();
        }
    }
}
